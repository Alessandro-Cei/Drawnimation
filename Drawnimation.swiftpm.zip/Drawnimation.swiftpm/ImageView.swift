import SwiftUI

struct ImageView: View, Identifiable {
    
    let component: UIImage
    var id = UUID()
    
    @State var viewState = CGSize.zero
    @State var isShowingPopover = false
    @State var rotationDuration: Double = 5
    @State var scale = 1.0
    @State var scaleDuration: Double = 5
    @State var degrees = Double(0.0)
    @State var isNotRemoved = true
    @State var movementDuration: Double = 5
    @State var repeatMovement = false
    @State var repeatScale = false
    @State var viewState2 = CGSize.zero
    @State var rotationDuration2: Double = 5
    @State var scale2 = 1.0
    @State var scaleDuration2: Double = 5
    @State var degrees2 = Double(0.0)
    @State var movementDuration2: Double = 5
    @State var repeatMovement2 = false
    @State var repeatScale2 = false
    
    var body: some View {
        
        if isNotRemoved {
            Image(uiImage: component)
                .resizable()
                .scaledToFit()
                .frame(width: 300, height: 300)
                .background(Color.clear)
                .offset(x: viewState.width, y: viewState.height)
                .scaleEffect(scale)
                .rotationEffect(Angle(degrees: degrees), anchor: .center)
                .animation(.linear(duration: movementDuration).repeatCount(repeatMovement ? 300 : 1, autoreverses: true), value: viewState)
                .animation(.linear(duration: scaleDuration).repeatCount(repeatScale ? 300 : 1, autoreverses: true), value: scale)
                .animation(.linear(duration: rotationDuration).repeatForever(autoreverses: false), value: degrees)
                .gesture(
                    DragGesture().onChanged { value in
                        
                        if value.location.x > -(UIScreen.main.bounds.width * 0.4)+150 && value.location.x < (UIScreen.main.bounds.width * 0.4)-150 {
                            viewState.width = value.location.x
                        }
                        
                        if value.location.y > -(UIScreen.main.bounds.height * 0.3)+150 && value.location.y < (UIScreen.main.bounds.height * 0.3)-150 {
                            viewState.height = value.location.y
                        }
                        
                    }
                )
                .onTapGesture {
                    self.isShowingPopover.toggle()
                }
                .popover(isPresented: $isShowingPopover, content: {
                    VStack {
                        List {
                            Section(header: Text("Rotation")){
                                Button {
                                    degrees2 = 360.0
                                } label: {
                                    Label("Rotate right", systemImage: "rotate.right")
                                }
                                Button {
                                    degrees2 = -360.0
                                } label: {
                                    Label("Rotate left", systemImage: "rotate.left")
                                }
                                HStack {
                                    Text("Duration")
                                    Slider(value: $rotationDuration2, in: 1...9)
                                }
                            }
                            Section(header: Text("Movement")){
                                Button {
                                    viewState2.height = -UIScreen.main.bounds.height * 0.3 + 150
                                } label: {
                                    Label("Move up", systemImage: "arrow.up")
                                }
                                Button {
                                    viewState2.height = UIScreen.main.bounds.height * 0.3 - 150
                                } label: {
                                    Label("Move down", systemImage: "arrow.down")
                                }
                                Button {
                                    viewState2.width = UIScreen.main.bounds.width * 0.4 - 150
                                } label: {
                                    Label("Move right", systemImage: "arrow.right")
                                }
                                Button {
                                    viewState2.width = -UIScreen.main.bounds.width * 0.4 + 150
                                } label: {
                                    Label("Move left", systemImage: "arrow.left")
                                }
                                HStack {
                                    Text("Duration")
                                    Slider(value: $movementDuration2, in: 1...9)
                                }
                                Toggle("Loop", isOn: $repeatMovement2)
                            }
                            Section(header: Text("Scale")){
                                HStack {
                                    Text("Dimension")
                                    Slider(value: $scale2, in: 1...5)
                                        .onTapGesture(){
                                            print(scale)
                                            print(scale2)
                                        }
                                }
                                HStack {
                                    Text("Duration")
                                    Slider(value: $scaleDuration2, in: 1...9)
                                        .onTapGesture(){
                                            print(scaleDuration)
                                            print(scaleDuration2)
                                        }
                                }
                                Toggle("Loop", isOn: $repeatScale2)
                                    .onTapGesture(){
                                        print(repeatScale)
                                        print(repeatScale2)
                                    }
                            }
                            Section(header: Text("Destructive")){
                                
                                Button {
                                    AnimateView()
                                } label: {
                                    Label("Animate component", systemImage: "play.square")
                                }
                                Button (role: .destructive) {
                                    isNotRemoved = false
                                } label: {
                                    Label("Remove component", systemImage: "trash")
                                        .foregroundColor(.red)
                                }
                            }
                        }
                        .listStyle(.grouped)
                    }
                    .frame(width: 300, height: 300)
            })
        }
    }
    
    func AnimateView(){
        viewState = viewState2
        rotationDuration = rotationDuration2
        scale = scale2
        scaleDuration = scaleDuration2
        degrees = degrees2
        movementDuration = movementDuration2
        repeatMovement = repeatMovement2
        repeatScale = repeatScale2
    }

}
