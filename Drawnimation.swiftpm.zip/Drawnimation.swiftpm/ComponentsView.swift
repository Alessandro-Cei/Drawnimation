import SwiftUI
import PencilKit

struct ComponentsView: View {
    
    @Binding var components: [ImageView]
    @State var canvas = PKCanvasView()
    
    var body: some View {
        
        NavigationView {
                ZStack {
                    ForEach(components) { x in
                        x
                    }
                }
                .frame(width: UIScreen.main.bounds.width * 0.8, height: UIScreen.main.bounds.height * 0.6)
        }
        .navigationViewStyle(.stack)
        .navigationBarTitleDisplayMode(.large)
        .navigationTitle(Text("Components"))
        .onDisappear(){
            components = []
        }
        
    }
}
