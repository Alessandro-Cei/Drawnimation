import SwiftUI
import PencilKit

struct DrawingCanvas: UIViewRepresentable {
    
    var canvasView: PKCanvasView
    let toolPicker = PKToolPicker.init()
    
    func makeUIView(context: Context) -> PKCanvasView {
        self.canvasView.tool = PKInkingTool(.pen, color: .black, width: 15)
        self.canvasView.becomeFirstResponder()
        self.canvasView.backgroundColor = UIColor.clear
        return canvasView
    }
    
    func updateUIView(_ uiView: PKCanvasView, context: Context) {
        toolPicker.addObserver(canvasView)
        toolPicker.setVisible(true, forFirstResponder: uiView)
        DispatchQueue.main.async {
            uiView.becomeFirstResponder()
        }
    }
    
}

struct ContentView: View {
    
    @State var canvas = PKCanvasView()
    @State var isPresented = false
    @State var components: [ImageView] = []
    @State var isActive = false
    @State var isEnoughDisabled = true
    @State var isEnoughBackground = Color(UIColor.systemGray)
    
    var body: some View {
        
        NavigationView {
            VStack (spacing: 60){
                    Text("Draw your components")
                        .font(.title)
                        .fontWeight(.bold)
                    DrawingCanvas(canvasView: canvas)
                        .frame(width: UIScreen.main.bounds.width * 0.8, height: UIScreen.main.bounds.height * 0.6, alignment: .center)
                        .border(Color(UIColor.white), width: 10)
                    HStack {
                        NavigationLink(destination: ComponentsView( components: $components), isActive: $isActive) {
                            Button {
                                isActive = true
                                isEnoughBackground = Color(UIColor.systemGray)
                                canvas.drawing = PKDrawing()
                                isEnoughDisabled = true
                            } label: {
                                Text("Enough")
                                    .frame(width: UIScreen.main.bounds.width * 0.2, height: 70, alignment: .center)
                                    .foregroundColor(.white)
                                    .font(.title2)
                                    .background(isEnoughBackground)
                                    .cornerRadius(15)
                            }
                        }
                        .disabled(isEnoughDisabled)
                        Spacer()
                        Button(action: {
                            if !canvas.drawing.strokes.isEmpty {
                                components.append(ImageView(component: canvas.drawing.image(from: canvas.drawing.bounds, scale: 1)))
                                canvas.drawing = PKDrawing()
                                isEnoughDisabled = false
                                isEnoughBackground = Color(UIColor.systemBlue)
                            }
                        }, label: {
                            Text("Add")
                                .frame(width: UIScreen.main.bounds.width * 0.2, height: 70, alignment: .center)
                                .foregroundColor(.white)
                                .font(.title2)
                                .background(Color(UIColor.systemBlue))
                                .cornerRadius(15)
                        })
                    }
                    .frame(width: UIScreen.main.bounds.width * 0.8, height: 70, alignment: .center)
            }
        }
        .navigationViewStyle(.stack)
        .navigationBarTitleDisplayMode(.large)
        .navigationTitle(Text("Components"))
        
    }
    
}


